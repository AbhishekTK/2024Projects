from setuptools import setup, find_packages

setup(
    name='course_scheduler',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
        # 'package1',
        # 'package2',
        # Add any other dependencies here
    ],
    # Additional metadata can be added here
)